package com.example.responsi_mobile_a2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
